import logoCMS from './Logo.png'
import nameCMS from './Name.png'
import banner from './banner.png'
import structure from './structure.png'
export {logoCMS , nameCMS , banner , structure} ;